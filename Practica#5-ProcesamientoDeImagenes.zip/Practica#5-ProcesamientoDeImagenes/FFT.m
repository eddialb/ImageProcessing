im = imread('Pimagenes2.png');
    
im=rgb2gray(im)
    F = fft2(im);

F2 = fftshift(F);
S = abs(F2);

S2 = log(1+S);
m = max(max(S2))
%cont = 0
%for x=1:length(S2)

%for y=1:length(S2)
 %   cont = S2(x,y);
  %  if S2(x,y) > cont 
   %    max = S2(x,y);
   % else  
   %    max = S2(x,y); 
   % end
   % end   
%end

S3= (S2*255)/m;
%for X=1:length(S2)
%    for Y=1:length(S2)
 %  
      %  S3(X,Y) = (S2(X,Y)/max)*255;   
       
        
  %  end
  %  end  

S3= uint8(S3);
surf(S3);
%imshow(S3,[]);
    figure;
    
    
    
  




