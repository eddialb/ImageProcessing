%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #3 %%
%%%% M�scaras de convoluci�n - PasaAltos %%%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Filtro_PasaAltos
SumMat=0;       %Variable que har� la suma de la matriz 3x3 de la imagen
imag=imread('ImagNormal.jpg');
imag0=rgb2gray(imag);
imag1=rgb2gray(imag);
[m,n]=size(imag0);
filtro=[-1,-1,-1;-1,8,-1;-1,-1,-1];     %filtro o m�scara a aplicar
for i=3:m-2     %for para moverse en la imagen
    for j=3:n-2
        for x=1:3       %for para mover la matriz del filtro en la imagen
            for y=1:3
            y1=double(imag0((i-3+x),(j-3+y)));  %Obtenemos el valor del pixel
            Suma=y1*filtro(x,y)+SumMat;     %Calculamos el valor de acuerdo al pixel y al valor del filtro
            SumMat=Suma;        %Acumulamos el valor en cada iteraci�n
            end
        end
        SumaFiltro=sum(sum(filtro));    %
        if SumaFiltro<1     %Para limitar en caso de...
        SumaFiltro=-2;
        end
        ValorPix=Suma/SumaFiltro;       %Valor nuevo que va a adquirir el pixel
        ValorPix1=uint8(ValorPix);
        imag1(i,j)=ValorPix1;
        SumMat=0;       %Se reinicia la suma.
    end
end
figure(1)
subplot(2,2,[1,3]);
imshow(imag0);
title('IMAGEN EN ESCALA DE GRISES ORIGINAL','Color','g');
subplot(2,2,[2,4]);
imshow(imag1);
title('IMAGEN EN ESCALA DE GRISES FILTRADA (PASA ALTOS)','Color','m');
end