%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #2 %%
%%%%%%%% ECUALIZACI�N DE HISTOGRAMA %%%%%%%%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;

imag=imread('altos.jpg');       %Cargamos la imagen.
imag=rgb2gray(imag);                    %Pasamos de RGB a escala de grises.
[f,c]=size(imag);                       %Obtenemos el tama�o de la imagen (pixelex).
pix=f*c;                                %N�mero total de pixeles de la imagen.
imagEc=imag;

G=zeros(1,256);                         %Creamos un vector de ceros con el n�mero de grises deseaso (256).
GAcum=zeros(1,256);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Segmento de elaboraci�n de histograma%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:f                               %For para moverse en las filas.
    for j=1:c                           %For para moverse en las columnas.
        for k=1:256                     %For para hallar el valor que contiene cierto pixel.
            if (imag(i,j)==k)           %Condici�n para saber si es ese valor el contenido en el pixel.
                G(k)=G(k)+1;            %Si es verdadera la condici�n, se incrementa en 1 el valor en la...
            end                         %...escala de grises que contenia dicho pixel.
        end
    end
    disp(i);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Obtenci�n de la frecuencia acumulada de la escala de grises %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
GAcum=G;                                %Copiamos las escalas de grises del histograma a un nuevo vector.
for i=1:256                             %For para llenar el nuevo vector.
    if (i==1)                           %Si estamos en la primera posici�n, se copia tal cual el el valor.
        GAcum(i)=GAcum(i);
    else                                
        if (GAcum(i)==0)                %Si el valor es 0, se replica el valor anterior del vector. 
            GAcum(i)=GAcum(i-1);
        else                            %De otra forma se copia el valor actual m�s el anterior.
        GAcum(i)=GAcum(i)+GAcum(i-1);
        end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%Inicio de ecualizaci�n %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('Ecualizando...'); 

for i=1:f                               %For para moverse en las filas de la nueva imagen.
    for j=1:c                           %For para moverse en las columnas de la nueva imagen.
        a=imag(i,j);                    %Guardamos en a el valor contenido en imag(i,j).
        if (a==0)                       %Si a es igual a 0, toma el valor de 1.
            a=1;
        end
        b=round((GAcum(a)/pix)*256);    %Obtenemos el nuevo valor que tendra el pixel.
        %disp(b);
        imagEc(i,j)=b;                  %Pasamos el nuevo valor del pixel a imagEc(i,j).
    end
end

imshow(imagEc);                         %Mostramos la nueva imagen.           