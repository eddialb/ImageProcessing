%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #4 %%
%%%%%% Filtros de Gradiente -  Mediana %%%%%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%function Filtro_Mediana
clear;
clc;

imag=imread('S&P2.png');       %Leemos la imagen.
%imag0=rgb2gray(imag);       %Se crean varias copias de la imagen.
%imag1=rgb2gray(imag);
imag0=imag;     %En caso de que la imagen s�lo tenga una dimensi�n
imag1=imag;

tam=5;      %Tama�o del intervalo
c=floor(tam/2);

[m,n]=size(imag0);      %Obtenemos tama�o de la imagen.

for i=1:m     %For para moverse en la imagen.
    for j=c+1:n-c
        AM=zeros(1,tam);
        aux1=1;
        aux2=1;
        for a=1:tam       %For para llenar el vector del intervalo
            if(a==(c+1))
                AM(a)=imag0(i,j);
            elseif(a<(c+1))
                AM(a)=imag0(i,j-(c+1-aux1));
                aux1=aux1+1;
            elseif(a>(c+1))
                AM(a)=imag0(i,j+aux2);
                aux2=aux2+1;
            end
        end
        for k=1:tam         %For para ordenar de menor a mayor el vector
            menor=AM(k);
            l=k;
            for m=k+1:tam
                if(AM(m)<menor)
                    menor=AM(m);
                    l=m;
                end
            end
            AM(l)=AM(k);
            AM(k)=menor;
        end
        imag1(i,j)=AM(c+1);     %Se asigna el nuevo valor a imag1 de la mediana
    end
end
figure(1)       %Graficamos las im�genes.
subplot(2,2,[1,3]);
imshow(imag0);
title('Original','Color','r');
subplot(2,2,[2,4]);
imshow(imag1);
title('Filtro de Mediana','Color','m');
%end