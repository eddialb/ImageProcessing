%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #4 %%
%%%%%%% Filtros de Gradiente -  Sobel %%%%%%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Filtro_Sobel
clear;
clc;
k1=0;
k2=0;

imag=imread('blackbird.jpg');       %Leemos la imagen.
imag0=rgb2gray(imag);       %Se crean varias copias de la imagen.
imag1=rgb2gray(imag);
imag2=rgb2gray(imag);
imag3=rgb2gray(imag);

m1=[-1,-2,-1;0,0,0;1,2,1];      %Matrices de Sobel.
m2=[-1,-2,-1;0,0,0;1,2,1];

[m,n]=size(imag0);      %Obtenemos tama�o de la imagen.

for i=2:m-1     %For para moverse en la imagen.
    for j=2:n-1
        for a=1:3       %For para moverse en las matrices de Sobel.
            for b=1:3
                y0=double(imag0((i-2+a),(j-2+b)));
                suma1=y0*m1(a,b)+k1;
                k1=suma1;
                suma2=y0*m2(a,b)+k2;
                k2=suma2;
            end
        end
        sumafiltro1=sum(sum(m1));
        if (sumafiltro1<1)      %Se ajusta un valor en caso de
            sumafiltro1=1;
        end
        sumafiltro2=sum(sum(m2));
        if (sumafiltro2<1)
            sumafiltro2=1;
        end
        valorPix1=suma1/sumafiltro1;        %Segmento de operaciones para
        valorPix2=suma2/sumafiltro2;        %el gradiente.
        valorPix01=uint8(valorPix1);
        valorPix02=uint8(valorPix2);
        imag1(i,j)=valorPix01;
        imag2(i,j)=valorPix02;
        k1=0;
        k2=0;
    end 
end
imag3=imag1+imag2;      %Se suman para darle m�s "intensidad" a los tonos
figure(1)       %Graficamos las im�genes.
subplot(2,2,[1,3]);
imshow(imag0);
title('Original','Color','r');
subplot(2,2,[2,4]);
imshow(imag3);
title('Gradiente Sobel','Color','m');
end