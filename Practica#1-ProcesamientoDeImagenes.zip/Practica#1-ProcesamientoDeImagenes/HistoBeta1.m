%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #1 %%
%%%%%% HISTOGRAMA EN ESCALA DE GRISES %%%%%%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;
clc;

imag=imread('ImagSobreExpuesta.jpg');       %Cargamos la imagen.
imag=rgb2gray(imag);                    %Pasamos de RGB a escala de grises.
[f,c]=size(imag);                       %Obtenemos el tama�o de la imagen (pixelex).
G=zeros(1,256);                         %Creamos un vector de ceros con el n�mero de grises deseaso (256).

for i=1:f                               %For para moverse en las filas.
    for j=1:c                           %For para moverse en las columnas.
        for k=1:256                     %For para hallar el valor que contiene cierto pixel.
            if (imag(i,j)==k)           %Condici�n para saber si es ese valor el contenido en el pixel.
                G(k)=G(k)+1;            %Si es verdadera la condici�n, se incrementa en 1 el valor en la...
            end                         %...escala de grises que contenia dicho pixel.
        end
    end
    disp(i);
end
bar(G);                                 %Imprimimos el vector G que contiene los tonos de grises y las...
                                        %...veces que dicho tono est� presente en la imagen.