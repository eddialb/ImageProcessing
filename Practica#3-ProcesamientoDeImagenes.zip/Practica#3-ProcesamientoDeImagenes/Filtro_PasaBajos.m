%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #3 %%
%%%% M�scaras de convoluci�n - PasaBajos %%%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function Filtro_PasaBajos
SumMat=0;
imag=imread('ImagNormal.jpg');
imag0=rgb2gray(imag);
imag1=rgb2gray(imag);
[m,n]=size(imag0);
filtro=[1,1,1;1,5,1;1,1,1];
for i=3:m-2
    for j=3:n-2
        for x=1:3
            for y=1:3
                y1=double(imag0((i-3+x),(j-3+y)));
                Suma=y1*filtro(x,y)+SumMat;
                SumMat=Suma;
            end
        end
        SumaFiltro=sum(sum(filtro));
        if (SumaFiltro<1)
        SumaFiltro=8;
        end
        ValorPix=Suma/SumaFiltro;
        ValorPix1=uint8(ValorPix);
        imag1(i,j)=ValorPix1;
        SumMat=0;
    end 
end
figure(1)
subplot(2,2,[1,3]);
imshow(imag0);
title('IMAGEN EN ESCALA DE GRISES ORIGINAL','Color','g');
subplot(2,2,[2,4]);
imshow(imag1);
title('IMAGEN EN ESCALA DE GRISES FILTRADA (PASA BAJOS)','Color','m');
end