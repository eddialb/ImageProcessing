clear;
clc;
pix=9;
%imag=imread();
imag=[2 1 0;0 1 3;4 1 4];
[f,c]=size(imag);

imagaux=zeros(f+2,c+2);
[f1,c1]=size(imagaux);

for i=2:f1-1
    for j=2:c1-1
        imagaux(i,j)=imag(i-1,j-1);
    end
end
imagaux
for i=2:f1-1
    for j=2:c1-1
        aux=zeros(3,3);
        for k=1:3
            for l=1:3
                if (k==1)
                    if (l==1)
                        aux(k,l)=imagaux(i-1,j-1);
                    elseif (l==2)
                        aux(k,l)=imagaux(i-1,j);
                    else
                        aux(k,l)=imagaux(i-1,j+1);
                    end
                elseif (k==2)
                    if (l==1)
                        aux(k,l)=imagaux(i,j-1);
                    elseif (l==2)
                        aux(k,l)=imagaux(i,j);
                    else
                        aux(k,l)=imagaux(i,j+1);
                    end
                else
                    if (l==1)
                        aux(k,l)=imagaux(i+1,j-1);
                    elseif (l==2)
                        aux(k,l)=imagaux(i+1,j);
                    else
                        aux(k,l)=imagaux(i+1,j+1);
                    end
                end
            end
        end
        %%%%AQU� TUVIMOS ERROR, YA QUE NO SE LLENA DE MANERA CORRECTA EL
        %%%%VECTOR G (ESCALA DE GRISES) Y POR ENDE LA PROBABILIDAD
        %%%%ACUMULADA Y LA ECUALIZACI�N NO SE REALIZAN DE MANERA CORRECTA.
        G=zeros(1,5);
        GAcum=zeros(1,5);
        for m=1:3
            for n=1:3
                for o=1:5
                    if (aux(m,n)==o)
                        G(o)=G(o)+1;
                    end
                end
            end
        end
        G
        GAcum=G;
        for m=1:5
            if (m==1)
                GAcum(m)=GAcum(m);
            else
                if (GAcum(m)==0)
                    GAcum(m)=GAcum(m-1);
                else
                    GAcum(m)=GAcum(m)+GAcum(m-1);
                end
            end
        end
        
        disp('Ecualizando...');
        auxEc=aux;
        for m=1:3
            for n=1:3
                a=aux(m,n);
                if(a==0)
                    a=1;
                end
                b=round((GAcum(a)/pix)*4);
                auxEc(m,n)=b;
            end
        end
        %auxEc
        imag(i-1,j-1)=auxEc(2,2);
    end
end
imag