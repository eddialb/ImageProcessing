%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #7 %%
%%% Filtros en frecuencia(FFT)-PASA.BANDA %%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
clear
clc
IM=imread('payaso.jpg');        %Leemos la imagen 
MASC=imread('puntosmasc.png');      %Leemos la mascara que aplicaremos
%IMG=rgb2gray(IMG);     %Pasamos a escala de grises tanto la imagen como...
MASC=rgb2gray(MASC);        %...la m�scara.
[m1,n1]=size(IM);       %Obtenemos dimensiones de la imagen y de la...
[m2,n2]=size(MASC);     %...m�scara.

%%Segemento donde obtenemos la FFT.
TF=fft2(IM);        %Aplicamos FFT a la imagen.
TF2=fftshift(TF);
TF2_ABS=abs(TF2);       %Obtenemos el valor absoluto de la FFT.
TF2_NORM=1+log(TF2_ABS);        %Para normalizar.

Val_Max=max(max(TF2_NORM));     %Obtenemos valor m�ximo.

TF_IM=uint8(zeros(m1,n1));      %Creamos matriz del espectro de frecuencias.

for i=1:m1      %Ciclo que llena dicha matriz para su visualizaci�n.
    for j=1:n1
        TF_IM(i,j)=round((TF2_NORM(i,j)/Val_Max)*(255));
    end
end

for k=1:m2      %Ciclo donde superponemos la m�scara a la FFT de la imagen.
    for l=1:n2
        if (MASC(k,l)<50)       %P�xeles menores que 50 adquieren valor de 0.
            TF2(k,l)=0;
        end
    end
end

%%Segmento donde aplicamos la IFFT.
ITF=ifftshift(TF2);
ITF2=ifft2(ITF); 
ITF2=uint8(ITF2);   

%%Segmento donde mostramos los resultados.
figure(1);
subplot(1,4,1), imshow(IM); 
title ('IMAGEN ORIGINAL','Color','r');
subplot(1,4,2), imshow(TF_IM); 
title ('ESPECTRO DE FRECUENCIA','Color','g');
subplot(1,4,3), imshow(MASC); 
title ('M�SCARA APLICADA','Color','b');
subplot(1,4,4), imshow(ITF2); 
title ('IMAGEN FILTRADA','Color','m');

