clear;
clc;
imag=imread('para_histograma_local.jpg');
imag=rgb2gray(imag);
%imag=[2 1 0;0 1 3;4 1 4];      %Para pruebas.
[f,c]=size(imag);
escG=255;
imagNew=imag;
imagaux=zeros(f+2,c+2);
[f1,c1]=size(imagaux);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Creaci�n de zero padding y asignaci�n de valores de la imagen %%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=2:f1-1
    for j=2:c1-1
        imagaux(i,j)=imag(i-1,j-1);
    end
end
%imagaux       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Proceso principal%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=2:f1-1        %for para moverse en la matriz del zero padding...
    for j=2:c1-1    %... e iniciamos en 2,2.
        aux=zeros(3,3);     %Creamos matriz de 3x3 para la ecualizaci�n local
        for k=1:3       %for para moverse en la matriz 3x3.
            for l=1:3   
                if (k==1)       %Segmento del c�digo donde vaciamos los... 
                    if (l==1)   %... valores de la imagen en la matriz 3x3.
                        aux(k,l)=imagaux(i-1,j-1);
                    elseif (l==2)
                        aux(k,l)=imagaux(i-1,j);
                    else
                        aux(k,l)=imagaux(i-1,j+1);
                    end
                elseif (k==2)
                    if (l==1)
                        aux(k,l)=imagaux(i,j-1);
                    elseif (l==2)
                        aux(k,l)=imagaux(i,j);
                    else
                        aux(k,l)=imagaux(i,j+1);
                    end
                else
                    if (l==1)
                        aux(k,l)=imagaux(i+1,j-1);
                    elseif (l==2)
                        aux(k,l)=imagaux(i+1,j);
                    else
                        aux(k,l)=imagaux(i+1,j+1);
                    end
                end             %Aqu� termina dicho segmento.
            end
        end
        %aux
        %Apartir de este segmento inicia procesor de Ecualizaci�n.
        G=zeros(1,escG+1);      %Creamos vector donde se guardar� la escala de grises.
        for m=1:3               %for para moverse en la matriz de 3x3.
            for n=1:3           
                for o=0:escG
                    if(aux(m,n)==o)
                        G(o+1)=G(o+1)+1;
                    end
                end
            end
        end
        GAcum=G;        %Creamos vector para la escala de grises acumulada.
        for m=1:escG+1
            if(m==1)
                GAcum(m)=GAcum(m);
            elseif (GAcum(m)==0)
                GAcum(m)=GAcum(m-1);
            else
                GAcum(m)=GAcum(m)+GAcum(m-1);
            end
        end
        %G
        %GAcum
        for m=1:3       %for para ecualizar la matriz 3x3.
            for n=1:3
                a=aux(m,n);
                b=round((GAcum(a+1)/9)*escG);
                aux(m,n)=b;
            end
        end
        %aux
        imagNew(i-1,j-1)=aux(2,2);      %Copiamos el valor que nos interesa de aux a la posici�n actual de la imagen.
        %imagNew                            
    end
    disp(i-1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%imag
%imagNew
imshow(imagNew);
GNew=zeros(1,256);
for i=1:f                               %For para moverse en las filas.
    for j=1:c                           %For para moverse en las columnas.
        for k=0:escG                     %For para hallar el valor que contiene cierto pixel.
            if (imagNew(i,j)==k)           %Condici�n para saber si es ese valor el contenido en el pixel.
                GNew(k+1)=GNew(k+1)+1;            %Si es verdadera la condici�n, se incrementa en 1 el valor en la...
            end                         %...escala de grises que contenia dicho pixel.
        end
    end
    disp(i);
end
%bar(GNew);
