%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PROCESAMIENTO DE IM�GENES - PR�CTICA #6 %%
%%% Filtros en frecuencia(FFT)-PASA.ALTOS %%%
%%%%% Integrantes:                    %%%%%%%
%%%%% * Garc�a S�nchez Eddi Alberto   %%%%%%%
%%%%% * Triana Hern�ndez Charly Uriel %%%%%%%
%%%%% * P�rez M�ndez Pedro Gonzalo    %%%%%%%
%%%%% * Garc�s M�ndez Mart�n          %%%%%%%
%%%%% * Chigo Rodr�guez Juan Jos�     %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
clear
clc
IM=imread('FaroNormal.jpg');    %Leemos la imagen.
IM=rgb2gray(IM);    %Pasamos a escala de grises.
[m,n]=size(IM);     %Obstenemos dimensiones de la imagen.

IM2=IM;     %Duplicado de la imagen.
rad=15;      %Variable que modifica el radio (en pixeles).
MatrizCir=zeros(m,n);   %Iniciamos matriz que contendr� el circulo.
xx=round(n/2);      %Variables que almacenan la mitad del tama�o...
yy=round(m/2);      %...de la imagen.
aux=0;      %Variable auxiliar.

%%SEGMENTO DONDE SE GENERA LA IMAGEN CON EL CIRCULO AL INTERIOR%%
while aux<rad
        y=abs(round(sqrt((rad^2)-(aux^2))));
        MatrizCir(yy+y,xx+round(aux))=1;
        MatrizCir(yy-y,xx+round(aux))=1;
        MatrizCir(yy+y,xx-round(aux))=1;
        MatrizCir(yy-y,xx-round(aux))=1;
        for i=0:y
            MatrizCir(yy+i,xx+round(aux))=1;
            MatrizCir(yy-i,xx+round(aux))=1;
            MatrizCir(yy+i,xx-round(aux))=1;
            MatrizCir(yy-i,xx-round(aux))=1;
        end
        aux=aux+0.1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
TF=fft2(IM2);   %Aplicamos FFT a la imagen.
TF2=fftshift(TF);
Masc=zeros(m,n);    %Creamos matriz para la m�scara.

for i=1:m       %For para convolucionar la la m�scara con la...
    for aux=1:n         %...FFT de la imagen.
        if MatrizCir(i,aux)==0  %igual a 0 para filtro pasa-altos.
            Masc(i,aux)=TF2(i,aux);
        end
    end
 end  

IMF=ifftshift(Masc);    %Aplicaci�n de IFFT a la m�scara para...
IMF2=ifft2(IMF);    %...obtener imagen filtrada.
IMF2=uint8(abs(IMF2));

%%SEGMENTO PARA MOSTRAR IMAGEN DEL CIRCULO, IMAGEN ORIGINAL E IMAGEN...
%%.. FILTRADA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1);
subplot(1,3,1);
imshow(MatrizCir);
title('M�SCARA','Color','g');
subplot(1,3,2);
imshow(IM2);
title('ORIGINAL','Color','r');
subplot(1,3,3);
imshow(IMF2);
title('FILTRO PASA-ALTOS','Color','m');